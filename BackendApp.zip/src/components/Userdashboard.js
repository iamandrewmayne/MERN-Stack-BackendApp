import React from "react";
import { useSelector } from "react-redux";

function Userdashboard() {
  let { user } = useSelector((state) => state.user);

  return (
    <div className="container">
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          height: "80vh",
        }}
      >
        <h1>
          <strong>
            UserDashboard!
            <br />
            Welcome {user.username}
          </strong>
        </h1>
      </div>
    </div>
  );
}

export default Userdashboard;
