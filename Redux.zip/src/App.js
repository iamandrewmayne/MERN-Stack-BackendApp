import React from "react";
import ReactDOM from "react-dom";
import "./App.css";
import Home from "./components/Home";
import Signin from "./components/Signin";
import Signup from "./components/Signup";
import { Navbar, Nav, Container } from "react-bootstrap";
import { NavLink, Routes, Route } from "react-router-dom";

function App() {
  return (
    <div>
      {/* Navbar */}
      <Navbar className="bg-dark navbar-dark" expand="sm">
        <Container>
          <Navbar.Brand href="/">Backend App</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto"></Nav>
            <Nav>
              <NavLink className="nav-link" to="/">
                Home
              </NavLink>
              <NavLink className="nav-link" to="/signup">
                Sign Up
              </NavLink>
              <NavLink className="nav-link" to="/signin">
                Sign In
              </NavLink>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <Routes>
        <Route path="/" element={<Home />}>
          Home
        </Route>
        <Route path="/signup" element={<Signup />}>
          Register
        </Route>
        <Route path="/signin" element={<Signin />}>
          Login
        </Route>
      </Routes>
    </div>
  );
}

export default App;
