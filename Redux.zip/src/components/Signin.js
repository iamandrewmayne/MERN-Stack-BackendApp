import axios from "axios";
import React from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";

function Signin() {
  let {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  //form submission
  const onFormSubmit = (userCredObj) => {};

  return (
    <div className="container">
      <p className="display-2 text-center">Login Here!</p>
      {/* User registration form */}
      <div className="row">
        <div className="col-12 col-sm-8 col-md-6 mx-auto">
          <form onSubmit={handleSubmit(onFormSubmit)}>
            {/* Username */}
            <div className="mb-3">
              <label for="username" className="form-label">
                Username
              </label>
              <input
                type="text"
                className="form-control"
                id="username"
                {...register("username")}
              />
            </div>
            {/* Password */}
            <div className="mb-3">
              <label for="password" className="form-label">
                Password
              </label>
              <input
                type="password"
                className="form-control"
                id="password"
                {...register("password")}
              />
            </div>
            <button type="submit" className="btn btn-primary">
              Sign In!
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Signin;
