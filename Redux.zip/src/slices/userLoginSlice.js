import { createSlice } from "@reduxjs/toolkit";

//create a slice
const userLoginSlice = createSlice({
  name: "userLogin",
  initialState: { value: 100 },
  reducers: {
    //reducer functions that can change the state
    incrementValue: (state, action) => {
      state.value = state.value + action.payload;
    },
    decrementValue: (state, action) => {
      state.value = state.value - action.payload;
    },
  },
  extraReducers: {},
});

export default userLoginSlice.reducer;
//action creator functions
export let { incrementValue, decrementValue } = userLoginSlice.actions;
